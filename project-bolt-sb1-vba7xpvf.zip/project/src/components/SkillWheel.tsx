interface SkillWheelProps {
  languages: string[];
}

function SkillWheel({ languages }: SkillWheelProps) {
  const radius = 80;
  const centerX = 100;
  const centerY = 100;
  const angleStep = (2 * Math.PI) / languages.length;

  return (
    <div className="glass-card rounded-2xl p-8 flex flex-col items-center">
      <h4 className="text-emerald-100 font-semibold mb-4 text-lg">Tecnologias</h4>

      <div className="relative w-[200px] h-[200px]">
        <svg width="200" height="200" className="absolute inset-0">
          <defs>
            <radialGradient id="skillGradient">
              <stop offset="0%" stopColor="rgba(52, 211, 153, 0.4)" />
              <stop offset="100%" stopColor="rgba(52, 211, 153, 0.05)" />
            </radialGradient>
          </defs>

          <circle
            cx={centerX}
            cy={centerY}
            r={radius}
            fill="url(#skillGradient)"
            stroke="rgba(52, 211, 153, 0.5)"
            strokeWidth="2"
            className="pulse-glow"
          />

          {languages.map((lang, index) => {
            const angle = index * angleStep - Math.PI / 2;
            const x = centerX + radius * Math.cos(angle);
            const y = centerY + radius * Math.sin(angle);

            return (
              <g key={lang}>
                <line
                  x1={centerX}
                  y1={centerY}
                  x2={x}
                  y2={y}
                  stroke="rgba(52, 211, 153, 0.3)"
                  strokeWidth="1.5"
                  className="animate-pulse"
                />
                <circle
                  cx={x}
                  cy={y}
                  r="8"
                  fill="rgba(52, 211, 153, 0.6)"
                  stroke="rgba(52, 211, 153, 0.9)"
                  strokeWidth="2"
                  className="hover:scale-110 transition-transform"
                />
              </g>
            );
          })}

          <circle
            cx={centerX}
            cy={centerY}
            r="12"
            fill="rgba(16, 185, 129, 0.8)"
            stroke="rgba(52, 211, 153, 1)"
            strokeWidth="3"
          />
        </svg>

        {languages.map((lang, index) => {
          const angle = index * angleStep - Math.PI / 2;
          const labelRadius = radius + 25;
          const x = centerX + labelRadius * Math.cos(angle);
          const y = centerY + labelRadius * Math.sin(angle);

          return (
            <div
              key={lang}
              className="absolute text-emerald-100 text-xs font-semibold text-center whitespace-nowrap"
              style={{
                left: `${x}px`,
                top: `${y}px`,
                transform: 'translate(-50%, -50%)',
              }}
            >
              {lang}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default SkillWheel;

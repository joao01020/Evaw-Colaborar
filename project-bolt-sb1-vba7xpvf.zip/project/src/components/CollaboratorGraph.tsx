import { Users } from 'lucide-react';

interface CollaboratorGraphProps {
  languages: Array<{ language: string; count: number }>;
  onSelectLanguage: (language: string) => void;
  selectedLanguage: string | null;
}

function CollaboratorGraph({ languages, onSelectLanguage, selectedLanguage }: CollaboratorGraphProps) {
  const maxCount = Math.max(...languages.map(l => l.count), 10);

  return (
    <div className="glass-card rounded-2xl p-6 mt-4">
      <div className="flex items-center gap-2 mb-4">
        <Users className="w-5 h-5 text-emerald-400" />
        <h4 className="text-emerald-100 font-semibold text-lg">
          Colaboradores Ativos
        </h4>
      </div>

      <p className="text-emerald-200/70 text-sm mb-4">
        Clique na linguagem que você quer começar a colaborar:
      </p>

      <div className="space-y-3">
        {languages.map(({ language, count }) => {
          const percentage = maxCount > 0 ? (count / maxCount) * 100 : 0;
          const isSelected = selectedLanguage === language;

          return (
            <button
              key={language}
              onClick={() => onSelectLanguage(language)}
              disabled={isSelected}
              className={`w-full text-left transition-all duration-300 ${
                isSelected ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105 cursor-pointer'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-sm font-medium ${
                  isSelected ? 'text-emerald-300' : 'text-emerald-100'
                }`}>
                  {language}
                  {isSelected && ' ✓'}
                </span>
                <span className="text-emerald-400 font-semibold text-sm">
                  {count}
                </span>
              </div>

              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    isSelected
                      ? 'bg-emerald-500/70'
                      : 'bg-gradient-to-r from-emerald-500 to-emerald-400'
                  }`}
                  style={{ width: `${Math.max(percentage, 5)}%` }}
                />
              </div>
            </button>
          );
        })}
      </div>

      {selectedLanguage && (
        <div className="mt-4 p-3 bg-emerald-500/20 border border-emerald-400/30 rounded-lg">
          <p className="text-emerald-100 text-sm text-center">
            Você agora é um colaborador de <strong>{selectedLanguage}</strong>!
          </p>
        </div>
      )}
    </div>
  );
}

export default CollaboratorGraph;

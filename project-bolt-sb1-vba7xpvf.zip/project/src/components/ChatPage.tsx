import { useState, useEffect, useRef } from 'react';
import { Send, ArrowLeft } from 'lucide-react';

interface ChatPageProps {
  selectedLanguage: 'frontend' | 'backend';
  onBack: () => void;
}

interface Message {
  id: string;
  name: string;
  text: string;
  timestamp: string;
  room: string;
}

function ChatPage({ selectedLanguage, onBack }: ChatPageProps) {
  const [activeTab, setActiveTab] = useState<'frontend' | 'backend'>(selectedLanguage);
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadMessages();
  }, [activeTab]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadMessages = () => {
    const storedMessages = localStorage.getItem(`evaw-chat-${activeTab}`);
    if (storedMessages) {
      setMessages(JSON.parse(storedMessages));
    } else {
      setMessages([]);
    }
  };

  const saveMessages = (newMessages: Message[]) => {
    localStorage.setItem(`evaw-chat-${activeTab}`, JSON.stringify(newMessages));
    setMessages(newMessages);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();

    if (!message.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      name: name.trim() || 'Anônimo',
      text: message.trim(),
      timestamp: new Date().toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit',
      }),
      room: activeTab,
    };

    const updatedMessages = [...messages, newMessage];
    saveMessages(updatedMessages);
    setMessage('');
  };

  const tabs = [
    { id: 'frontend' as const, label: 'Frontend', subtitle: 'HTML, CSS, JS' },
    { id: 'backend' as const, label: 'Backend', subtitle: 'C++, Python' },
  ];

  return (
    <div className="min-h-screen flex flex-col px-4 py-8">
      <div className="max-w-5xl w-full mx-auto flex flex-col h-[calc(100vh-4rem)]">
        <div className="mb-6">
          <button
            onClick={onBack}
            className="glass-button rounded-lg px-4 py-2 text-white flex items-center gap-2 mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </button>

          <div className="flex gap-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`glass-card rounded-xl px-6 py-3 transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'bg-emerald-500/30 border-emerald-400/50'
                    : 'hover:bg-emerald-500/10'
                }`}
              >
                <div className="text-white font-semibold">{tab.label}</div>
                <div className="text-emerald-200/70 text-xs">{tab.subtitle}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="glass-card rounded-2xl flex-1 flex flex-col overflow-hidden">
          <div className="p-6 border-b border-white/10">
            <h2 className="text-2xl font-bold text-white glow-text">
              Sala {activeTab === 'frontend' ? 'Frontend' : 'Backend'}
            </h2>
            <p className="text-emerald-200/70 text-sm mt-1">
              {messages.length} mensagens
            </p>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 ? (
              <div className="text-center text-emerald-200/50 py-12">
                Nenhuma mensagem ainda. Seja o primeiro a enviar!
              </div>
            ) : (
              messages.map((msg) => (
                <div key={msg.id} className="chat-message glass-card rounded-xl p-4">
                  <div className="flex items-start justify-between mb-2">
                    <span className="font-semibold text-emerald-400">{msg.name}</span>
                    <span className="text-emerald-200/50 text-xs">{msg.timestamp}</span>
                  </div>
                  <p className="text-white/90">{msg.text}</p>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={handleSendMessage} className="p-6 border-t border-white/10">
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Seu nome (opcional)"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full glass-card rounded-xl px-4 py-3 text-white placeholder-emerald-200/40 focus:outline-none focus:ring-2 focus:ring-emerald-400/50"
              />

              <div className="flex gap-3">
                <input
                  type="text"
                  placeholder="Digite sua mensagem..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="flex-1 glass-card rounded-xl px-4 py-3 text-white placeholder-emerald-200/40 focus:outline-none focus:ring-2 focus:ring-emerald-400/50"
                  required
                />

                <button
                  type="submit"
                  className="glass-button rounded-xl px-6 py-3 text-white flex items-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  Enviar
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ChatPage;

import { useState } from 'react';
import { Code2, Database, Network } from 'lucide-react';
import LanguageCard from './LanguageCard';

interface WelcomePageProps {
  onEnterRoom: (language: 'frontend' | 'backend') => void;
}

function WelcomePage({ onEnterRoom }: WelcomePageProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      <div className="max-w-6xl w-full space-y-12">
        <div className="text-center space-y-6 float-animation">
          <div className="flex items-center justify-center mb-6">
            <Network className="w-16 h-16 text-emerald-400 glow-text" />
          </div>

          <h1 className="text-5xl md:text-7xl font-bold text-white glow-text tracking-tight">
            Pioneiros do Evaw
          </h1>

          <p className="text-xl md:text-2xl text-emerald-100 max-w-3xl mx-auto leading-relaxed font-light">
            Bem-vindos, Pioneiros do Evaw — uma rede descentralizada onde conhecimento, criatividade e colaboração viram valor.
          </p>

          <div className="glass-card rounded-2xl p-8 max-w-2xl mx-auto">
            <p className="text-emerald-50 text-lg leading-relaxed">
              O Evaw conecta desenvolvedores e criadores para construir uma rede aberta de código e conhecimento.
              Escolha sua área de interesse e junte-se à comunidade.
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <LanguageCard
            title="Frontend"
            icon={<Code2 className="w-12 h-12" />}
            languages={['HTML', 'CSS', 'JavaScript']}
            description="Desenvolvimento de interfaces e experiências web"
            type="frontend"
            onEnterRoom={onEnterRoom}
          />

          <LanguageCard
            title="Backend"
            icon={<Database className="w-12 h-12" />}
            languages={['C++', 'Python']}
            description="Desenvolvimento de servidores e lógica de negócios"
            type="backend"
            onEnterRoom={onEnterRoom}
          />
        </div>

        <footer className="text-center pt-12">
          <p className="text-emerald-200/70 text-sm font-light">
            Projeto Evaw — Conectando ideias que constroem o futuro descentralizado.
          </p>
        </footer>
      </div>
    </div>
  );
}

export default WelcomePage;

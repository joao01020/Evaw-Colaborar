import { useState, useEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import SkillWheel from './SkillWheel';
import CollaboratorGraph from './CollaboratorGraph';
import { getCollaboratorCounts, incrementCollaboratorCount } from '../lib/supabase';

interface LanguageCardProps {
  title: string;
  icon: React.ReactNode;
  languages: string[];
  description: string;
  type: 'frontend' | 'backend';
  onEnterRoom: (type: 'frontend' | 'backend') => void;
}

function LanguageCard({ title, icon, languages, description, type, onEnterRoom }: LanguageCardProps) {
  const [showWheel, setShowWheel] = useState(false);
  const [collaborators, setCollaborators] = useState<Array<{ language: string; count: number }>>([]);
  const [selectedLanguage, setSelectedLanguage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (showWheel) {
      loadCollaboratorCounts();
    }
  }, [showWheel]);

  const loadCollaboratorCounts = async () => {
    const counts = await getCollaboratorCounts(languages);
    setCollaborators(counts);
  };

  const handleCardClick = () => {
    setShowWheel(!showWheel);
    if (!showWheel) {
      setSelectedLanguage(null);
    }
  };

  const handleSelectLanguage = async (language: string) => {
    if (selectedLanguage === language) return;

    setLoading(true);
    const success = await incrementCollaboratorCount(language);

    if (success) {
      setSelectedLanguage(language);
      await loadCollaboratorCounts();
    }

    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <div
        onClick={handleCardClick}
        className="glass-card rounded-2xl p-8 cursor-pointer hover:scale-105 transition-all duration-300 group"
      >
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="text-emerald-400 group-hover:scale-110 transition-transform duration-300">
            {icon}
          </div>

          <h3 className="text-3xl font-semibold text-white glow-text">
            {title}
          </h3>

          <div className="flex flex-wrap gap-2 justify-center">
            {languages.map((lang) => (
              <span
                key={lang}
                className="px-3 py-1 bg-emerald-500/20 border border-emerald-400/30 rounded-full text-emerald-100 text-sm"
              >
                {lang}
              </span>
            ))}
          </div>

          <p className="text-emerald-100/80 text-sm">
            {description}
          </p>

          <div className="text-emerald-300 text-xs mt-2 opacity-70">
            Clique para ver detalhes e colaboradores
          </div>
        </div>
      </div>

      {showWheel && (
        <div className="skill-wheel space-y-4">
          <SkillWheel languages={languages} />

          {collaborators.length > 0 && (
            <CollaboratorGraph
              languages={collaborators}
              onSelectLanguage={handleSelectLanguage}
              selectedLanguage={selectedLanguage}
            />
          )}

          <button
            onClick={() => onEnterRoom(type)}
            disabled={!selectedLanguage || loading}
            className={`glass-button w-full rounded-xl py-4 px-6 text-white font-semibold flex items-center justify-center gap-2 ${
              !selectedLanguage || loading ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            {loading ? 'Carregando...' : 'Entrar na Sala'}
            <ArrowRight className="w-5 h-5" />
          </button>

          {!selectedLanguage && (
            <p className="text-emerald-200/60 text-xs text-center">
              Selecione uma linguagem para continuar
            </p>
          )}
        </div>
      )}
    </div>
  );
}

export default LanguageCard;

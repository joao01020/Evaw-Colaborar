import { useState } from 'react';
import { Code2, Database, MessagesSquare } from 'lucide-react';
import WelcomePage from './components/WelcomePage';
import ChatPage from './components/ChatPage';

function App() {
  const [currentPage, setCurrentPage] = useState<'welcome' | 'chat'>('welcome');
  const [selectedLanguage, setSelectedLanguage] = useState<'frontend' | 'backend'>('frontend');

  const handleEnterRoom = (language: 'frontend' | 'backend') => {
    setSelectedLanguage(language);
    setCurrentPage('chat');
  };

  const handleBackToWelcome = () => {
    setCurrentPage('welcome');
  };

  return (
    <div className="min-h-screen">
      {currentPage === 'welcome' ? (
        <WelcomePage onEnterRoom={handleEnterRoom} />
      ) : (
        <ChatPage selectedLanguage={selectedLanguage} onBack={handleBackToWelcome} />
      )}
    </div>
  );
}

export default App;

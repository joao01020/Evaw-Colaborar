import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Collaborator {
  id: string;
  language: string;
  count: number;
  created_at: string;
  updated_at: string;
}

export async function getCollaboratorCounts(languages: string[]) {
  const { data, error } = await supabase
    .from('collaborators')
    .select('language, count')
    .in('language', languages);

  if (error) {
    console.error('Error fetching collaborator counts:', error);
    return [];
  }

  return data || [];
}

export async function incrementCollaboratorCount(language: string) {
  const { data: current, error: fetchError } = await supabase
    .from('collaborators')
    .select('count')
    .eq('language', language)
    .maybeSingle();

  if (fetchError) {
    console.error('Error fetching current count:', fetchError);
    return false;
  }

  const newCount = (current?.count || 0) + 1;

  const { error: updateError } = await supabase
    .from('collaborators')
    .update({ count: newCount, updated_at: new Date().toISOString() })
    .eq('language', language);

  if (updateError) {
    console.error('Error updating count:', updateError);
    return false;
  }

  return true;
}

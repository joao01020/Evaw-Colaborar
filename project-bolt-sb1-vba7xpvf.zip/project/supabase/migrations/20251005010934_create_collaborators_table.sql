/*
  # Create Collaborators Table

  1. New Tables
    - `collaborators`
      - `id` (uuid, primary key) - Unique identifier for each record
      - `language` (text) - Programming language (HTML, CSS, JavaScript, C++, Python)
      - `count` (integer) - Number of active collaborators for this language
      - `created_at` (timestamptz) - Record creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  2. Security
    - Enable RLS on `collaborators` table
    - Add policy for anyone to read collaborator counts (public data)
    - Add policy for authenticated users to update counts

  3. Initial Data
    - Insert initial records for each language with count starting at 0
*/

CREATE TABLE IF NOT EXISTS collaborators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  language text UNIQUE NOT NULL,
  count integer DEFAULT 0 NOT NULL CHECK (count >= 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE collaborators ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view collaborator counts"
  ON collaborators
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can update collaborator counts"
  ON collaborators
  FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

INSERT INTO collaborators (language, count) 
VALUES 
  ('HTML', 0),
  ('CSS', 0),
  ('JavaScript', 0),
  ('C++', 0),
  ('Python', 0)
ON CONFLICT (language) DO NOTHING;
